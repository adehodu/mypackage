from setuptools import setup, find_packages

setup(
    name='mypackage',
    version='0.1',
    long_description=open('readme.md').read()
)